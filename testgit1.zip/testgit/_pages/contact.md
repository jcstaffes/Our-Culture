---
ID: 34
post_title: Contact
author: Eric
post_excerpt: ""
layout: page
permalink: >
  http://anugraduatehouse.online/index.php/contact/
published: true
post_date: 2020-05-08 08:02:04
---
<!-- wp:paragraph -->
<p><strong>This page contains the contact details for relevant authorities in the house.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p><strong><em>Master of University House</em></strong></p>
<!-- /wp:paragraph -->

<!-- wp:image {"align":"center","id":408,"width":266,"height":265,"sizeSlug":"large","className":"is-style-rounded"} -->
<div class="wp-block-image is-style-rounded"><figure class="aligncenter size-large is-resized"><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.25.50-PM-1-1024x1019.png" alt="" class="wp-image-408" width="266" height="265"/><figcaption><strong>Peter Kanowski</strong><br>m:&nbsp;6125 5334<br>e: peter.kanowsk@anu.edu.au</figcaption></figure></div>
<!-- /wp:image -->

<!-- wp:paragraph -->
<p><strong><em>Group of contacts</em></strong></p>
<!-- /wp:paragraph -->

<!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:gallery {"ids":[413,415,421,418,419,420]} -->
<figure class="wp-block-gallery columns-3 is-cropped"><ul class="blocks-gallery-grid"><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.25.58-PM-1-1024x1024.png" alt="" data-id="413" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.25.58-PM-1.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-25-58-pm-1/" class="wp-image-413"/><figcaption class="blocks-gallery-item__caption">Matthew Dowdney</figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.18-PM-1.png" alt="" data-id="415" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.18-PM-1.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-26-18-pm-2/" class="wp-image-415"/><figcaption class="blocks-gallery-item__caption">Robert Freeth</figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.28.53-PM-1.png" alt="" data-id="421" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.28.53-PM-1.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-28-53-pm-2/" class="wp-image-421"/><figcaption class="blocks-gallery-item__caption">Graduate House Reception</figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.30-PM.png" alt="" data-id="418" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.30-PM.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-26-30-pm/" class="wp-image-418"/><figcaption class="blocks-gallery-item__caption">Kaori Oikawa-Ruthven</figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.36-PM.png" alt="" data-id="419" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.36-PM.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-26-36-pm/" class="wp-image-419"/><figcaption class="blocks-gallery-item__caption">Hoa Dao</figcaption></figure></li><li class="blocks-gallery-item"><figure><img src="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.42-PM.png" alt="" data-id="420" data-full-url="http://anugraduatehouse.online/wp-content/uploads/2020/05/Screen-Shot-2020-05-19-at-11.26.42-PM.png" data-link="http://anugraduatehouse.online/index.php/contact/screen-shot-2020-05-19-at-11-26-42-pm/" class="wp-image-420"/><figcaption class="blocks-gallery-item__caption">Margaret Kiley</figcaption></figure></li></ul></figure>
<!-- /wp:gallery --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->

<!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:spacer -->
<div style="height:100px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group -->

<!-- wp:html -->
[google_map_easy id="1"]
<!-- /wp:html -->

<!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:group -->
<div class="wp-block-group"><div class="wp-block-group__inner-container"><!-- wp:social-links -->
<ul class="wp-block-social-links"><!-- wp:social-link {"url":"https://www.facebook.com/groups/anu.gh/","service":"facebook"} /-->

<!-- wp:social-link {"service":"twitter"} /-->

<!-- wp:social-link {"service":"instagram"} /-->

<!-- wp:social-link {"service":"linkedin"} /-->

<!-- wp:social-link {"service":"youtube"} /--></ul>
<!-- /wp:social-links --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group --></div></div>
<!-- /wp:group -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->