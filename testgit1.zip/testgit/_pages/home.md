---
ID: 19
post_title: Home
author: u6801714@anu.edu.au
post_excerpt: ""
layout: page
permalink: http://anugraduatehouse.online/
published: true
post_date: 2020-05-08 07:41:10
---
<!-- wp:paragraph -->
<p>Welcome to the University House student area.<br>This section of the site is for University and Graduate House resident postgraduates only.</p>
<!-- /wp:paragraph -->