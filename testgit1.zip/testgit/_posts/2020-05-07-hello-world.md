---
ID: 1
post_title: Hello world!
author: u6801714@anu.edu.au
post_excerpt: ""
layout: post
permalink: >
  http://anugraduatehouse.online/index.php/2020/05/07/hello-world/
published: true
post_date: 2020-05-07 22:39:02
---
<!-- wp:paragraph -->
<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>
<!-- /wp:paragraph -->