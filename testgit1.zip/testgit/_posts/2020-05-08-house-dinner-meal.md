---
ID: 124
post_title: House Dinner – Meal
author: u6801714@anu.edu.au
post_excerpt: ""
layout: post
permalink: >
  http://anugraduatehouse.online/index.php/2020/05/08/house-dinner-meal/
published: true
post_date: 2020-05-08 11:39:39
---
<!-- wp:heading {"level":4} -->
<h4><em>May 13 @ 4:00 pm - 6:00 pm</em></h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>House Dinner is being replaced this week with individually delivered meals.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>University House is organising for individual meals to be created and delivered to Graduate House or Gowrie Hall.<br>The meal will be provided in a takeaway container that residents can heat and eat.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The House Dinner registration process is the same, but you will need to register and request a meal before 10 am Monday 11 of May.<br>Please also include any dietary requirements when you make this request.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Meal collection</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Graduate House<br>The meal will be available from Graduate House reception between 4 pm to 6.00 pm on Wednesday.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Gowrie Hall</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The meal will be placed in a shared fridge in the Gowrie Hall kitchen at 4 pm on Wednesday.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Menu</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Main Course<br>Lemon Thyme Chicken Thigh, Creamed Mash, Honey Carrots<br>Garden salad</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Vegetarian Option<br>Braised Chick Peas in Harissa, potato, spiced yoghurt, gremolata<br>Garden salad</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Dessert<br>Bread and butter pudding</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="http://anugraduatehouse.online/index.php/news/dinner-booking/" rel="">I'M ATTENDING</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->