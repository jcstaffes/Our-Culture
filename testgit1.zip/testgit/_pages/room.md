---
ID: 30
post_title: Room
author: u6801714@anu.edu.au
post_excerpt: ""
layout: page
permalink: >
  http://anugraduatehouse.online/index.php/room/
published: true
post_date: 2020-05-08 08:01:38
---
<p>3D VIRTUAL TOURS</p>

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="https://www.papermonkey.com.au/3d-virtual-tours/anu-graduate-house/">Click Here!</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->