---
ID: 186
post_title: Shut up and write
author: u6801714@anu.edu.au
post_excerpt: ""
layout: post
permalink: >
  http://anugraduatehouse.online/index.php/2020/05/13/shut-up-and-write/
published: true
post_date: 2020-05-13 04:42:54
---
<!-- wp:heading {"level":3} -->
<h3>May 15 @ 5:30 am - 9:00 pm</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>During work from home, academic productivity is impacted the most and for this the UH/GH SLT is organizing “May special Shut Up and Write session” to provide an opportunity to the residents to work together and enhance productivity.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>During the session, we will follow “Pomodoro Technique” of short intense bursts (25 mins) of writing/reading in supportive environment followed by beak (5 mins). It’s open of all the residents (PhD/M.Phil/Masters), so feel free to work on assignments/research/writing/reading during the session.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Dinner will be provided to registered participants. Please register before the end of Wednesday of the week of the SUAW session through the button below.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Title: UH/GH Shut Up and Write (May Special)<br>Date &amp; Time: 8th May, 15th May, 22nd May and 29th May 2020; 5:30 pm – 9 pm<br>Place: Online Zoom (https://anu.zoom.us/j/97774859417)</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>For more details or questions, please contact Chitresh (Chitresh.Saraswat@anu.edu.au), Sherin (Sherin@anu.edu.au) and Nikita (Nikita.Gagrani@anu.edu.au)</p>
<!-- /wp:paragraph -->

<!-- wp:table -->
<figure class="wp-block-table"><table><tbody><tr><td><strong><em>Details:</em></strong></td></tr><tr><td><strong><em>Date:</em></strong><br>May 15</td></tr><tr><td><strong><em>Time:</em></strong><br>5:30 am - 9:00 pm</td></tr><tr><td><strong><em>Website:</em></strong><br><a href="https://anu.zoom.us/j/97774859417">https://anu.zoom.us/j/97774859417</a></td></tr><tr><td><strong><em>Venue</em></strong><br>Zoom<br>Australia</td></tr><tr><td><strong><em>Organizers</em></strong><br>Chitresh Saraswat<br>Nikita Gagrani</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="http://anugraduatehouse.online/index.php/news/dinner-booking/">I'm Attending</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p></p>
<!-- /wp:paragraph -->