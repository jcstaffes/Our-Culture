---
ID: 122
post_title: Food Menu
author: u6801714@anu.edu.au
post_excerpt: ""
layout: page
permalink: >
  http://anugraduatehouse.online/index.php/food-menu/
published: true
post_date: 2020-05-08 11:34:54
---
<!-- wp:food-and-drink-menu/menu {"id":63} /-->